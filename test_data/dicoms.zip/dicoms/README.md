# Example dataset with dicom files for a structural T1-weighted scan

Dicom files for 1 subject's T1 scan. Please see the following link for data source and license: 
    
- [dcm2nii Sample Dicom Images](https://www.nitrc.org/plugins/mwiki/index.php/dcm2nii:MainPage#Sample_DICOM_Images)

**Note:** A sample demographic file with randomly generated Age and Sex values is provided for illustrative purposes.
